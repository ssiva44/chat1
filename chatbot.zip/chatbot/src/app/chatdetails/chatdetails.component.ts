import { Component, EventEmitter, OnInit,Output } from '@angular/core';
import {HttpClient,HttpHeaders} from '@angular/common/http';

import { saveAs } from 'file-saver';
import { from, Observable } from 'rxjs';
import * as data from'../data.json';
import {FormGroup,FormControl,Validator, Validators} from '@angular/forms'
declare var require: any;

var fs = require("file-saver");
@Component({
  selector: 'chatdetails',
  templateUrl: './chatdetails.component.html',
  styleUrls: ['./chatdetails.component.css']
})
export class ChatdetailsComponent implements OnInit {
  projecttitle:string="";
  modeofdeploy:string="";
  urlProjectdetails:string="";
  designpath:string="";
  testForms: FormGroup;
  @Output() test=new EventEmitter<any>();
  jsppath:string="";
  dataPath:any= data;
  constructor(public http:HttpClient) { }

  ngOnInit(): void {
    this.testForms=new FormGroup({
      title:new FormControl('',[Validators.required])
    })
  }
  btnclear(){
    this.projecttitle="";
  this.modeofdeploy="";
  this.urlProjectdetails="";
  this.designpath=""
  this.jsppath="";
  }
  btnsave(){
    debugger
let obj={
  projectTitle:this.projecttitle,
  modeofdeploy:this.modeofdeploy,
  url:this.urlProjectdetails,
  designpath:this.designpath,
  jsppath:this.jsppath
};
this.test.emit(obj);
debugger
// this.http.post("../data.json",JSON.stringify(obj)).subscribe((data:any)=>{
// debugger
// });
this.postJson(obj).subscribe((data:any) => {
  debugger
  console.log('Post: ' + data)
});
  }

  public postJson(obj: any): Observable<any> {
    debugger
    const httpOptions = {
        headers: new HttpHeaders({
            'Content-Type': 'application/json'
        })
    };
    return this.http.post("../data.json", JSON.stringify(obj), httpOptions);
}
}
